pick_a_capital_4web


		
# 简介 
选取的国家，操练Python语言开发练习：使用flask


		
## 输入：
用户输入国家
## 输出：
用户得到输出结果为：首都
## 从输入到输出，本组作品使用了：
### 模块
* [csv](https://github.com/thephpleague/csv)
### 数据
* [简中CLDR country-capitals](https://github.com/chenweishan/country-capitals/blob/master/data/country-list.json)
### API
* [github](https://api.github.com/)

## 作者成员：
见[_team_.tsv](_team_/_team_.tsv)


		成员列表，统计用，一人一行，输入Github 帐户名即可（此行完成後应删）
